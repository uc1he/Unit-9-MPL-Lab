/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Owner
 */
public class CustomTee extends TeeShirt {
    private String slogan;

    // Get method for slogan
    public String getSlogan() {
        return slogan;
    }

    // Set method for slogan
    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }
}
